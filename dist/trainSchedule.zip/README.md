# Node API Templete

01.Run command [npm start] on Git Base or Command Prompt.
